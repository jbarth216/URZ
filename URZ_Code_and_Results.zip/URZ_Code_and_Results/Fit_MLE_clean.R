library("DEoptim")

SCGT <- read.csv("ump_games_link_2023.csv")
df_called <- read.csv("df_called.csv")

Res23 <- data.frame(ump_name = unique(SCGT$ump), num_games = 0, num_calls=0,
                    sigx=0,sigz=0, b1_r=0, b1_l=0, b2_r=0, b2_l=0, b3=0, b4=0,
                    LL=0)
for (i in 1:nrow(Res23)){
  gms <- SCGT$game_pk[SCGT$ump==Res23$ump_name[i]]
  Res23$num_games[i] <- length(gms)
  Res23$num_calls[i] <- nrow(df_called[df_called$game_pk %in% gms,])
  
  DE_obj<- DEoptim(opt_function_BIAS_STANCE,
                   lower = c(1e-5,1e-5,-.5,-.5,-.5,-.5, -.5, -.5),
                   upper = c(1,1,.5,.5,.5,.5, .5, .5),
                   control = DEoptim.control(
                     trace = FALSE  # or trace = 0
                   ),
                   use_prior=0,
                   sig=0.25,
                   ds=df_called[df_called$game_pk %in% gms,])
  Res23[i,4:11] <- DE_obj$optim$bestmem
  Res23[i,12] <- DE_obj$optim$bestval
  print(i)
}

Res23_ord <- Res23[order(Res23$ump_id),]

#write.csv(Res23, "Res_by_ump_23.csv")