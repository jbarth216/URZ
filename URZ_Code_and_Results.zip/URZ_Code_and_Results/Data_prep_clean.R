#### NOTE: This r-file is included for posterity. The complete dataset has been uploaded
#### to github in as df_called.csv. You do not need to run this script, you can simply
#### run df_called <- read.csv("df_called.csv")


library(baseballr)
library(lubridate)
library(dplyr)


setwd("C:\\Users\\Jackson_Barth\\Box\\Research\\Baseball\\DATA")

##For now, load only 2023 data
## DATA LOAD ####

df <- read.csv("March23_pitchdata.csv")
df <- rbind(df, read.csv("April23_pitchdata.csv"))
df <- rbind(df, read.csv("May23_pitchdata.csv"))
df <- rbind(df, read.csv("June_Sep23_pitchdata.csv"))

non_swing_AB <- c("called_strike","ball","blocked_ball","pitchout")
df_called <- df[df$description %in% non_swing_AB,]
df_called <- df_called[!is.na(df_called$plate_x),]

## FUNCTIONS ####

boundary_check <- Vectorize(function(x,z, sz_top,sz_bot, l=-0.83, r=0.83){
  zs <- ((z-sz_bot)/(sz_top-sz_bot))
  if(x > r & zs >= 0 & zs <= 1){"E"} else
    if(x < l & zs >= 0 & zs <= 1){"W"} else
      if(x <= r & x >= l & zs < 0 ){"S"} else
        if(x <= r & x >= l & zs > 1){"N"} else
          
          if(x < l & zs > 1){"NW"} else
            if(x < l & zs < 0){"SW"} else
              if(x > r & zs > 1){"NE"} else
                if(x > r & zs < 0){"SE"} else
                  if(x <= r & x >= l & zs >= 0 & zs <= 1){"STK"} else{"Error"}
})

shadow_check <- Vectorize(function(x,z, sz_top,sz_bot, l=-0.83, r=0.83){
  adj <- 2.94/12 ###This is a ball's length on either side
  inner <- ifelse(x>(l+adj) & x<(r-adj) & z>(sz_bot + adj) & z<(sz_top-adj),1,0)
  outer <- ifelse(x>(l-adj) & x<(r+adj) & z>(sz_bot - adj) & z<(sz_top+adj),1,0)
  
  ifelse(inner==0 & outer==1,1,0)
})

### Add actual location ####

for (i in 1:nrow(df_called)){
  df_called$location[i] <- boundary_check(df_called$plate_x[i],
                                          df_called$plate_z[i],
                                          df_called$sz_top[i] + .12,
                                          df_called$sz_bot[i] - .12,
                                          -0.83, 0.83)
}

df_called$actual <- ifelse(df_called$location=="STK",1,0)
df_called$predicted <- ifelse(df_called$description=="called_strike",1,0)

## Add shadow check ####

df_called$shadow <- shadow_check(df_called$plate_x, df_called$plate_z,
                                 df_called$sz_top, df_called$sz_bot)

## Exploratory: Where do missed calls happen? ####
## First add "correct" column to simplify this

df_called$correct <- ifelse(df_called$actual == df_called$predicted,1,0)
df_called$row_id <- 1:nrow(df_called)
#(df_called[df_called$correct == 0,])[1:10,]


### Upload umpire info (see ump_code_USEME.R) ####
SCGT <- read.csv("ump_games_link_2023.csv")

SCGT$ump_id <- as.integer(factor(SCGT$ump))
ump_id_table <- unique(SCGT[,6:7])
df_called$ump_id <- 0
for(i in 1:94){
  df_called$ump_id[df_called$game_pk %in% SCGT$game_pk[SCGT$ump_id==i]] <- i
}

Res23$ump_id <- ump_id_table$ump_id[match(Res23$ump_name, ump_id_table$ump)]


###Note: Rho_diff was added using an early version of the global_rho stan results
###Essentially, it checks to see if a 0 correlation ends up having a substantial
###impact on the predicted probabilities fitted. This is very conservative (i.e.,
###a difference of .01 LL counts as substantial) and allows us to flag pitches
###that require the more complex and time-consuming BVN CDF calculation, and use
###quicker computation on all other pitches
 
params_list <- list()

for (i in 1:94){
  params_list[[i]] <- c(paste0("sigx[",i,"]"),
                        paste0("sigz[",i,"]"),
                        paste0("b1_r[",i,"]"),
                        paste0("b1_l[",i,"]"),
                        paste0("b2_r[",i,"]"),
                        paste0("b2_l[",i,"]"),
                        paste0("b3[",i,"]"),
                        paste0("b4[",i,"]"),
                        "rho")
}

lp_rho <- list()
diff_set <- numeric(0)
diff_mag <- numeric(94)
for (u in 1:94){
  
  par <- params_list[[u]]
  test <- df_called[df_called$ump_id==u,]
  
  lp_rho[[u]] <- matrix(0,nrow(test),3)
  pars <- sm$mean[sm$variable %in% par]
  lp_rho[[u]][,1] <- test$row_id
  lp_rho[[u]][,2] <- pitch_logprob_BIAS_STANCE_rho2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                                    pars[7], pars[8], pars[9], pars[1], test)
  lp_rho[[u]][,3] <- pitch_logprob_BIAS_STANCE_rho2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                                    pars[7], pars[8], pars[9], 0, test)
  
  abs_diffs <- abs(lp_rho[[u]][,2] - lp_rho[[u]][,3])
  diff_set1 <- lp_rho[[u]][abs_diffs>.01,1]
  diff_set <- c(diff_set, diff_set1)
  diff_mag[u] <- sum(abs_diffs)
}

df_called$rho_diff <- 0
df_called$rho_diff[df_called$row_id %in% diff_set] <- 1

df_called$rho_diff <- 0
df_called$rho_diff[df_called$row_id %in% diff_set] <- 1
