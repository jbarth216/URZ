### Optimization functions ####


library(pbivnorm) ### Used only for the functions that relax independence


###Independent ####

pitch_logprob <- function(sigx,sigz, x, z, sz_top, sz_bot, called_strike){
  xprob <- pnorm(0.83-x, 0, sd = sigx) - pnorm(-0.83 - x, 0, sd = sigx)
  zprob <- pnorm(sz_top - z, 0, sd = sigz) - pnorm(sz_bot - z, 0, sd = sigz)
  log(called_strike*(xprob*zprob) + (1-called_strike)*(1-xprob*zprob))
}

pitch_logprob_BIAS_STANCE <- function(sigx,sigz, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                      x, z, sz_top, sz_bot, called_strike, bh){
  xprob_l <- pnorm(0.83-x + b1_l, 0, sd = sigx) -
    pnorm(-0.83 - x + b2_l, 0, sd = sigx)
  xprob_r <- pnorm(0.83-x + b1_r, 0, sd = sigx) -
    pnorm(-0.83 - x + b2_r, 0, sd = sigx)
  xprob <- ifelse(bh=="R",xprob_r, xprob_l)
  zprob <- pnorm(sz_top - z + b3, 0, sd = sigz) -
    pnorm(sz_bot - z + b4, 0, sd = sigz)
  
  prob <- called_strike*(xprob*zprob) + (1-called_strike)*(1-xprob*zprob)
  ifelse(prob==0,-10000,log(prob))
}

pitch_logprob_BIAS_STANCE2 <- function(sigx,sigz, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                       ds){
  x <- ds$plate_x
  z <- ds$plate_z
  sz_top <- ds$sz_top
  sz_bot <- ds$sz_bot
  called_strike <- ds$predicted
  bh <- ds$stand
  xprob_l <- pnorm(0.83-x + b1_l, 0, sd = sigx) -
    pnorm(-0.83 - x + b2_l, 0, sd = sigx)
  xprob_r <- pnorm(0.83-x + b1_r, 0, sd = sigx) -
    pnorm(-0.83 - x + b2_r, 0, sd = sigx)
  xprob <- ifelse(bh=="R",xprob_r, xprob_l)
  zprob <- pnorm(sz_top - z + b3, 0, sd = sigz) -
    pnorm(sz_bot - z + b4, 0, sd = sigz)
  
  prob <- called_strike*(xprob*zprob) + (1-called_strike)*(1-xprob*zprob)
  ifelse(prob==0,-10000,log(prob))
}

opt_function_BIAS_STANCE <- function(pars, use_prior=0, sig=100, ds=game_ex){
  loglik <- -1*sum(pitch_logprob_BIAS_STANCE(pars[1], pars[2], pars[3], pars[4], pars[5],
                                             pars[6], pars[7], pars[8], ds$plate_x, ds$plate_z,
                                             ds$sz_top, ds$sz_bot, ds$predicted, ds$stand))
  
  logprior <- sum(dnorm(pars[3:6],0,sig, log=TRUE))
  
  loglik - use_prior*logprior
}


### Top/Bottom sigz ####

pitch_logprob_BIAS_STANCE_TB <- function(sigx, sigz_top, sigz_bot, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                         x, z, sz_top, sz_bot, called_strike, bh){
  
  sigz <- ifelse(z < sz_bot + (sz_top - sz_bot)/2,sigz_bot, sigz_top)
  xprob <- pnorm(0.83-x + ifelse(bh=="R", b1_r,b1_l), 0, sd = sigx) -
    pnorm(-0.83 - x + ifelse(bh=="R", b2_r,b2_l), 0, sd = sigx)
  
  zprob <- pnorm(sz_top - z + b3, 0, sd = sigz) -
    pnorm(sz_bot - z + b4, 0, sd = sigz)
  
  prob <- called_strike*(xprob*zprob) + (1-called_strike)*(1-xprob*zprob)
  ifelse(prob==0,-10000,log(prob))
}

opt_function_BIAS_STANCE_TB <- function(pars, use_prior=0, sig=100, ds=game_ex){
  loglik <- -1*sum(pitch_logprob_BIAS_STANCE_TB(pars[1], pars[2], pars[3], pars[4], pars[5],
                                                pars[6], pars[7], pars[8], pars[9], ds$plate_x, ds$plate_z,
                                                ds$sz_top, ds$sz_bot, ds$predicted, ds$stand))
  
  logprior <- sum(dnorm(pars[4:7],0,sig, log=TRUE))
  
  loglik - use_prior*logprior
}

pitch_logprob_BIAS_STANCE_TB2 <- function(sigx,sigz_top, sigz_bot, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                          ds){
  pitch_logprob_BIAS_STANCE_TB(sigx,sigz_top, sigz_bot, b1_r, b1_l, b2_r, b2_l, b3, b4,
                               ds$plate_x, ds$plate_z, ds$sz_top, ds$sz_bot,
                               ds$predicted, ds$stand)
}

## Rho ####

rect_prob <- function(x1, x2, y1, y2, rho) {
  pbivnorm(x2, y2, rho) - pbivnorm(x1, y2, rho) -
    pbivnorm(x2, y1, rho) + pbivnorm(x1, y1, rho)
}

pitch_logprob_BIAS_STANCE_rho <- function(sigx,sigz, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                          rho, x, z, sz_top, sz_bot, called_strike, bh){
  if ( rho < -1 || rho > 1){-1e100} else {
    sr <- 0.83 + ifelse(bh=="R",b1_r, b1_l)
    sl <- -0.83 + ifelse(bh=="R",b2_r, b2_l)
    st <- sz_top + b3
    sb <- sz_bot + b4
    x1 <- (sl-x)/sigx
    x2 <- (sr-x)/sigx
    z1 <- (sb-z)/sigz
    z2 <- (st-z)/sigz
    
    str_prob <- rect_prob(x1, x2, z1, z2,rho)
    prob <- called_strike*str_prob + (1-called_strike)*(1-str_prob)
    ifelse(prob<=0,-1e100,log(prob))
  }
}

pitch_logprob_BIAS_STANCE_rho2 <- function(sigx,sigz, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                           rho, ds){
  pitch_logprob_BIAS_STANCE_rho(sigx,sigz, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                rho, ds$plate_x, ds$plate_z, ds$sz_top, ds$sz_bot,
                                ds$predicted, ds$stand)
}

opt_function_BIAS_STANCE_rho <- function(pars, use_prior=0, sig=100, ds=game_ex){
  loglik <- -1*sum(pitch_logprob_BIAS_STANCE_rho(pars[1], pars[2], pars[3], pars[4], pars[5],
                                                 pars[6], pars[7], pars[8], pars[9], ds$plate_x, ds$plate_z,
                                                 ds$sz_top, ds$sz_bot, ds$predicted, ds$stand))
  
  logprior <- sum(dnorm(pars[3:6],0,sig, log=TRUE))
  
  loglik - use_prior*logprior
}

## Full ####

pitch_logprob_BIAS_STANCE_bth <- function(sigx,sigz_top, sigz_bot, b1_r, b1_l, b2_r, b2_l, b3, b4,
                                          rho, x, z, sz_top, sz_bot, called_strike, bh){
  if ( rho < -1 || rho > 1){-1e100} else {
    sigz <- ifelse(z < sz_bot + (sz_top - sz_bot)/2,sigz_bot, sigz_top)
    sr <- 0.83 + ifelse(bh=="R",b1_r, b1_l)
    sl <- -0.83 + ifelse(bh=="R",b2_r, b2_l)
    st <- sz_top + b3
    sb <- sz_bot + b4
    x1 <- (sl-x)/sigx
    x2 <- (sr-x)/sigx
    z1 <- (sb-z)/sigz
    z2 <- (st-z)/sigz
    
    str_prob <- rect_prob(x1, x2, z1, z2,rho)
    prob <- called_strike*str_prob + (1-called_strike)*(1-str_prob)
    ifelse(prob<=0,-1e100,log(prob))
  }
}

pitch_logprob_BIAS_STANCE_bth2 <- function(sigx,sigz_top, sigz_bot, b1_r, b1_l,
                                           b2_r, b2_l, b3, b4, rho, ds){
  pitch_logprob_BIAS_STANCE_bth(sigx,sigz_top, sigz_bot, b1_r, b1_l, b2_r, b2_l,
                                b3, b4, rho, ds$plate_x, ds$plate_z, ds$sz_top,
                                ds$sz_bot, ds$predicted, ds$stand)
}

opt_function_BIAS_STANCE_bth <- function(pars, use_prior=0, sig=100, ds=game_ex){
  
  loglik <- -1*sum(pitch_logprob_BIAS_STANCE_rho(pars[1], pars[2], pars[3], pars[4], pars[5],
                                                 pars[6], pars[7], pars[8], pars[9], pars[10],
                                                 ds$plate_x, ds$plate_z,
                                                 ds$sz_top, ds$sz_bot, ds$predicted, ds$stand))
  
  logprior <- sum(dnorm(pars[3:6],0,sig, log=TRUE))
  
  loglik - use_prior*logprior
}
