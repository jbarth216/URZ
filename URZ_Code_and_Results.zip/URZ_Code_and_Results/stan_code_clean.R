#### FINAL RUNS FOR PAPER ####

library(cmdstanr)

#### Load Data ####
df_called <- read.csv("df_called.csv")
Res23 <- read.csv("Res_by_ump_23.csv")  ###MLE results
Res23_ord <- Res23[order(Res23$ump_id),]

#### Load Models
model_ind <- cmdstan_model("HM_ind.stan",
                           cpp_options = list(stan_threads = TRUE))
model_TB <- cmdstan_model("HM_TB.stan", 
                          cpp_options = list(stan_threads = TRUE))
model_rho1_corner <- cmdstan_model("HM_rho1_corner.stan", 
                                   cpp_options = list(stan_threads = TRUE))
model_bth <- cmdstan_model("HM_bth.stan", cpp_options = list(stan_threads = TRUE))

### Initialization Functions ####
## Note: Since the hierarchical models were introduced primarily for shrinkage,
## we initialized all chains around the MLEs for fast convergence.
## Claude was used to help write these initialization functions

##ind

build_init_fn <- function(
    mle_sigx,   # length-U vector, per-umpire MLE for sigx
    mle_sigz,   # length-U vector, per-umpire MLE for sigz
    mle_b1_r,   # length-U vector, per-umpire MLE for b1_r
    mle_b1_l,
    mle_b2_r,
    mle_b2_l,
    mle_b3,
    mle_b4,
    jitter_sd = 0.01   # small noise so chains don't start identically
) {
  
  # small helper: back-solve non-centered params from a vector of MLEs
  # returns list(mu, tau, z) such that mu + tau*z ~= target (on whatever scale target is on)
  solve_noncentered <- function(target) {
    mu  <- mean(target)
    tau <- sd(target)
    if (!is.finite(tau) || tau < 1e-4) tau <- 0.05   # guard against degenerate/zero spread
    z   <- (target - mu) / tau
    list(mu = mu, tau = tau, z = z)
  }
  
  # sigx, sigz are modeled on the log scale (sigx = exp(mu_log_sigx + tau*z))
  sx <- solve_noncentered(log(mle_sigx))
  sz <- solve_noncentered(log(mle_sigz))
  
  # bias terms are modeled on the natural scale (b = mu + tau*z)
  b1r <- solve_noncentered(mle_b1_r)
  b1l <- solve_noncentered(mle_b1_l)
  b2r <- solve_noncentered(mle_b2_r)
  b2l <- solve_noncentered(mle_b2_l)
  b3_ <- solve_noncentered(mle_b3)
  b4_ <- solve_noncentered(mle_b4)
  
  U <- length(mle_sigx)
  
  function() {
    list(
      mu_log_sigx  = sx$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigx = max(sx$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigx   = sx$z   + rnorm(U, 0, jitter_sd),
      
      mu_log_sigz  = sz$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigz = max(sz$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigz   = sz$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_r  = b1r$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_r = max(b1r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_r   = b1r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_l  = b1l$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_l = max(b1l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_l   = b1l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_r  = b2r$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_r = max(b2r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_r   = b2r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_l  = b2l$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_l = max(b2l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_l   = b2l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b3  = b3_$mu  + rnorm(1, 0, jitter_sd),
      tau_b3 = max(b3_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b3   = b3_$z   + rnorm(U, 0, jitter_sd),
      
      mu_b4  = b4_$mu  + rnorm(1, 0, jitter_sd),
      tau_b4 = max(b4_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b4   = b4_$z   + rnorm(U, 0, jitter_sd)
    )
  }
}

init_fn <- build_init_fn(
  mle_sigx = Res23_ord$sigx,   
  mle_sigz = Res23_ord$sigz,
  mle_b1_r = Res23_ord$b1_r,
  mle_b1_l = Res23_ord$b1_l,
  mle_b2_r = Res23_ord$b2_r,
  mle_b2_l = Res23_ord$b2_l,
  mle_b3   = Res23_ord$b3,
  mle_b4   = Res23_ord$b4
)

##TB

build_init_fn_tb <- function(
    mle_sigx,   # length-U vector, per-umpire MLE for sigx
    mle_sigz, # length-U vector, per-umpire MLE for sigz
    mle_b1_r,   # length-U vector, per-umpire MLE for b1_r
    mle_b1_l,
    mle_b2_r,
    mle_b2_l,
    mle_b3,
    mle_b4,
    jitter_sd = 0.01   # small noise so chains don't start identically
) {
  
  # small helper: back-solve non-centered params from a vector of MLEs
  # returns list(mu, tau, z) such that mu + tau*z ~= target (on whatever scale target is on)
  solve_noncentered <- function(target) {
    mu  <- mean(target)
    tau <- sd(target)
    if (!is.finite(tau) || tau < 1e-4) tau <- 0.05   # guard against degenerate/zero spread
    z   <- (target - mu) / tau
    list(mu = mu, tau = tau, z = z)
  }
  
  # sigx, sigz are modeled on the log scale (sigx = exp(mu_log_sigx + tau*z))
  sx <- solve_noncentered(log(mle_sigx))
  sz <- solve_noncentered(log(mle_sigz))
  
  # bias terms are modeled on the natural scale (b = mu + tau*z)
  b1r <- solve_noncentered(mle_b1_r)
  b1l <- solve_noncentered(mle_b1_l)
  b2r <- solve_noncentered(mle_b2_r)
  b2l <- solve_noncentered(mle_b2_l)
  b3_ <- solve_noncentered(mle_b3)
  b4_ <- solve_noncentered(mle_b4)
  
  U <- length(mle_sigx)
  
  function() {
    list(
      mu_log_sigx  = sx$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigx = max(sx$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigx   = sx$z   + rnorm(U, 0, jitter_sd),
      
      mu_log_sigz_top  = sz$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigz_top = max(sz$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigz_top   = sz$z   + rnorm(U, 0, jitter_sd),
      
      mu_log_sigz_bot  = sz$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigz_bot = max(sz$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigz_bot   = sz$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_r  = b1r$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_r = max(b1r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_r   = b1r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_l  = b1l$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_l = max(b1l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_l   = b1l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_r  = b2r$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_r = max(b2r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_r   = b2r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_l  = b2l$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_l = max(b2l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_l   = b2l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b3  = b3_$mu  + rnorm(1, 0, jitter_sd),
      tau_b3 = max(b3_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b3   = b3_$z   + rnorm(U, 0, jitter_sd),
      
      mu_b4  = b4_$mu  + rnorm(1, 0, jitter_sd),
      tau_b4 = max(b4_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b4   = b4_$z   + rnorm(U, 0, jitter_sd)
    )
  }
}

init_fn_tb <- build_init_fn_tb(
  mle_sigx = Res23_ord$sigx,
  mle_sigz = Res23_ord$sigz,
  mle_b1_r = Res23_ord$b1_r,
  mle_b1_l = Res23_ord$b1_l,
  mle_b2_r = Res23_ord$b2_r,
  mle_b2_l = Res23_ord$b2_l,
  mle_b3   = Res23_ord$b3,
  mle_b4   = Res23_ord$b4
)

##rho1

build_init_fn_rho1 <- function(
    mle_sigx,   # length-U vector, per-umpire MLE for sigx
    mle_sigz,   # length-U vector, per-umpire MLE for sigz
    mle_b1_r,   # length-U vector, per-umpire MLE for b1_r
    mle_b1_l,
    mle_b2_r,
    mle_b2_l,
    mle_b3,
    mle_b4,
    jitter_sd = 0.01   # small noise so chains don't start identically
) {
  
  # small helper: back-solve non-centered params from a vector of MLEs
  # returns list(mu, tau, z) such that mu + tau*z ~= target (on whatever scale target is on)
  solve_noncentered <- function(target) {
    mu  <- mean(target)
    tau <- sd(target)
    if (!is.finite(tau) || tau < 1e-4) tau <- 0.05   # guard against degenerate/zero spread
    z   <- (target - mu) / tau
    list(mu = mu, tau = tau, z = z)
  }
  
  # sigx, sigz are modeled on the log scale (sigx = exp(mu_log_sigx + tau*z))
  sx <- solve_noncentered(log(mle_sigx))
  sz <- solve_noncentered(log(mle_sigz))
  
  # bias terms are modeled on the natural scale (b = mu + tau*z)
  b1r <- solve_noncentered(mle_b1_r)
  b1l <- solve_noncentered(mle_b1_l)
  b2r <- solve_noncentered(mle_b2_r)
  b2l <- solve_noncentered(mle_b2_l)
  b3_ <- solve_noncentered(mle_b3)
  b4_ <- solve_noncentered(mle_b4)
  
  U <- length(mle_sigx)
  
  function() {
    list(
      mu_log_sigx  = sx$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigx = max(sx$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigx   = sx$z   + rnorm(U, 0, jitter_sd),
      
      mu_log_sigz  = sz$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigz = max(sz$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigz   = sz$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_r  = b1r$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_r = max(b1r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_r   = b1r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_l  = b1l$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_l = max(b1l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_l   = b1l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_r  = b2r$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_r = max(b2r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_r   = b2r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_l  = b2l$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_l = max(b2l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_l   = b2l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b3  = b3_$mu  + rnorm(1, 0, jitter_sd),
      tau_b3 = max(b3_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b3   = b3_$z   + rnorm(U, 0, jitter_sd),
      
      mu_b4  = b4_$mu  + rnorm(1, 0, jitter_sd),
      tau_b4 = max(b4_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b4   = b4_$z   + rnorm(U, 0, jitter_sd),
      
      rho = 0
    )
  }
}

init_fn_rho1 <- build_init_fn_rho1(
  mle_sigx = Res23_ord$sigx,
  mle_sigz = Res23_ord$sigz,
  mle_b1_r = Res23_ord$b1_r,
  mle_b1_l = Res23_ord$b1_l,
  mle_b2_r = Res23_ord$b2_r,
  mle_b2_l = Res23_ord$b2_l,
  mle_b3   = Res23_ord$b3,
  mle_b4   = Res23_ord$b4
)

##full

build_init_fn_bth <- function(
    mle_sigx,   # length-U vector, per-umpire MLE for sigx
    mle_sigz, # length-U vector, per-umpire MLE for sigz
    mle_b1_r,   # length-U vector, per-umpire MLE for b1_r
    mle_b1_l,
    mle_b2_r,
    mle_b2_l,
    mle_b3,
    mle_b4,
    jitter_sd = 0.01   # small noise so chains don't start identically
) {
  
  # small helper: back-solve non-centered params from a vector of MLEs
  # returns list(mu, tau, z) such that mu + tau*z ~= target (on whatever scale target is on)
  solve_noncentered <- function(target) {
    mu  <- mean(target)
    tau <- sd(target)
    if (!is.finite(tau) || tau < 1e-4) tau <- 0.05   # guard against degenerate/zero spread
    z   <- (target - mu) / tau
    list(mu = mu, tau = tau, z = z)
  }
  
  # sigx, sigz are modeled on the log scale (sigx = exp(mu_log_sigx + tau*z))
  sx <- solve_noncentered(log(mle_sigx))
  sz <- solve_noncentered(log(mle_sigz))
  
  # bias terms are modeled on the natural scale (b = mu + tau*z)
  b1r <- solve_noncentered(mle_b1_r)
  b1l <- solve_noncentered(mle_b1_l)
  b2r <- solve_noncentered(mle_b2_r)
  b2l <- solve_noncentered(mle_b2_l)
  b3_ <- solve_noncentered(mle_b3)
  b4_ <- solve_noncentered(mle_b4)
  
  U <- length(mle_sigx)
  
  function() {
    list(
      mu_log_sigx  = sx$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigx = max(sx$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigx   = sx$z   + rnorm(U, 0, jitter_sd),
      
      mu_log_sigz_top  = sz$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigz_top = max(sz$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigz_top   = sz$z   + rnorm(U, 0, jitter_sd),
      
      mu_log_sigz_bot  = sz$mu  + rnorm(1, 0, jitter_sd),
      tau_log_sigz_bot = max(sz$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_log_sigz_bot   = sz$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_r  = b1r$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_r = max(b1r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_r   = b1r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b1_l  = b1l$mu  + rnorm(1, 0, jitter_sd),
      tau_b1_l = max(b1l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b1_l   = b1l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_r  = b2r$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_r = max(b2r$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_r   = b2r$z   + rnorm(U, 0, jitter_sd),
      
      mu_b2_l  = b2l$mu  + rnorm(1, 0, jitter_sd),
      tau_b2_l = max(b2l$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b2_l   = b2l$z   + rnorm(U, 0, jitter_sd),
      
      mu_b3  = b3_$mu  + rnorm(1, 0, jitter_sd),
      tau_b3 = max(b3_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b3   = b3_$z   + rnorm(U, 0, jitter_sd),
      
      mu_b4  = b4_$mu  + rnorm(1, 0, jitter_sd),
      tau_b4 = max(b4_$tau + rnorm(1, 0, jitter_sd), 1e-3),
      z_b4   = b4_$z   + rnorm(U, 0, jitter_sd),
      
      rho= .5 + rnorm(1,0,jitter_sd)
    )
  }
}

init_fn_bth <- build_init_fn_bth(
  mle_sigx = Res23_ord$sigx,
  mle_sigz = Res23_ord$sigz,
  mle_b1_r = Res23_ord$b1_r,
  mle_b1_l = Res23_ord$b1_l,
  mle_b2_r = Res23_ord$b2_r,
  mle_b2_l = Res23_ord$b2_l,
  mle_b3   = Res23_ord$b3,
  mle_b4   = Res23_ord$b4
)

###Note: The inv_metrics - these were saved from older, longer runs for tuning
###primarily for the cross validation analysis so as to have a reasonable
###starting point for this




### Independent Model
model_ind <- cmdstan_model("HM_ind.stan",
                           cpp_options = list(stan_threads = TRUE))

inv_met_init_warmup <- readRDS("inv_met.rdata")

stan_data <- list(
  N = nrow(df_called),
  U = 94,
  ump = df_called$ump_id,
  x = df_called$plate_x,
  z = df_called$plate_z,
  sz_top = df_called$sz_top,
  sz_bot = df_called$sz_bot,
  bh = as.integer(df_called$stand == "L"),
  cs = df_called$predicted,
  grainsize=50000
)

fit_ind <- model_ind$sample(data=stan_data, chains=4, parallel_chains = 4,
                            iter_warmup=100, iter_sampling=500, refresh=50,
                            init=init_fn, threads_per_chain = 3, step_size=.0977342,
                            inv_metric=inv_met_init_warmup)

#saveRDS(fit_ind,"fit_ind.rdata")


### Full Model ####

inv_met_bth <- readRDS(inv_met_bth.rdata)

stan_data <- list(
  N = nrow(df_called),
  U = 94,
  ump = df_called$ump_id,
  is_corner = df_called$rho_diff,
  x = df_called$plate_x,
  z = df_called$plate_z,
  sz_top = df_called$sz_top,
  sz_bot = df_called$sz_bot,
  bh = as.integer(df_called$stand == "L"),
  cs = df_called$predicted,
  grainsize=50000
)


fit_full <- model_bth$sample(data=stan_data, chains=4, parallel_chains = 4,
                             iter_warmup=100, iter_sampling=500, refresh=50,
                             init=init_fn_bth, threads_per_chain = 3, step_size=0.0794531,
                             inv_metric=inv_met_bth)

fit_full_sum <- fit_full$summary()
#write.csv(fit_full_sum,"fit_full_sum.csv")
#saveRDS(fit_full, "fit_full.rdata")

### TB ####

stan_data <- list(
  N = nrow(df_called),
  U = 94,
  ump = df_called$ump_id,
  x = df_called$plate_x,
  z = df_called$plate_z,
  sz_top = df_called$sz_top,
  sz_bot = df_called$sz_bot,
  bh = as.integer(df_called$stand == "L"),
  cs = df_called$predicted,
  grainsize=50000
)

inv_met_init_warmup <- readRDS("inv_met_init_TB.rdata")

fit_TB_final <- model_TB$sample(data=stan_data, chains=4, parallel_chains = 4,
                                iter_warmup=100, iter_sampling=500, refresh=50,
                                init=init_fn_tb, threads_per_chain = 3, step_size=.1209,
                                inv_metric=inv_met_init_warmup)

saveRDS(fit_TB_final, "fit_TB_final.rdata")


## rho1 ####

stan_data <- list(
  N = nrow(df_called),
  U = 94,
  ump = df_called$ump_id,
  is_corner = df_called$rho_diff,
  x = df_called$plate_x,
  z = df_called$plate_z,
  sz_top = df_called$sz_top,
  sz_bot = df_called$sz_bot,
  bh = as.integer(df_called$stand == "L"),
  cs = df_called$predicted,
  grainsize=50000
)

corn_met <- readRDS("corn_met.rdata")

fit_rho1_fin <- model_rho1_corner$sample(data=stan_data, chains=4, parallel_chains = 4,
                                         iter_warmup=100, iter_sampling=500, refresh=50,
                                         init=init_fn_rho1, threads_per_chain = 3, step_size=.08828,
                                         inv_metric=corn_met)


#saveRDS(fit_rho1_fin, "fit_rho1_fin.rdata")

### Build Results Table ####

fit_ind <- readRDS("fit_ind.rdata")
fit_full <- readRDS("fit_full.rdata")

## Independent
ind_sum <- fit_ind$summary()
write.csv(ind_sum,"ind_sum_paper.csv")

mean(ind_sum$mean[grepl("^sigx",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^sigx",ind_sum$variable)]*12)

mean(ind_sum$mean[grepl("^sigz",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^sigz",ind_sum$variable)]*12)

mean(ind_sum$mean[grepl("^b1_r",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^b1_r",ind_sum$variable)]*12)

mean(ind_sum$mean[grepl("^b1_l",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^b1_l",ind_sum$variable)]*12)

mean(ind_sum$mean[grepl("^b2_r",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^b2_r",ind_sum$variable)]*12)

mean(ind_sum$mean[grepl("^b2_l",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^b2_l",ind_sum$variable)]*12)

mean(ind_sum$mean[grepl("^b3",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^b3",ind_sum$variable)]*12)

mean(ind_sum$mean[grepl("^b4",ind_sum$variable)])*12
sd(ind_sum$mean[grepl("^b4",ind_sum$variable)]*12)


## rho1
rho1_sum <- fit_rho1_fin$summary()
write.csv(rho1_sum,"rho1_sum_paper.csv")


mean(rho1_sum$mean[grepl("^sigx",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^sigx",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("^sigz",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^sigz",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("^b1_r",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^b1_r",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("^b1_l",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^b1_l",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("^b2_r",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^b2_r",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("^b2_l",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^b2_l",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("^b3",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^b3",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("^b4",rho1_sum$variable)])*12
sd(rho1_sum$mean[grepl("^b4",rho1_sum$variable)]*12)

mean(rho1_sum$mean[grepl("rho",rho1_sum$variable)])
#sd(rho1_sum$mean[grepl("rho",rho1_sum$variable)]*12)


## TB
TB_sum <- fit_TB_final$summary()
write.csv(TB_sum,"TB_sum_paper.csv")


mean(TB_sum$mean[grepl("^sigx",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^sigx",TB_sum$variable)]*12)

mean(TB_sum$mean[grepl("^sigz_top",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^sigz_top",TB_sum$variable)]*12)

mean(TB_sum$mean[grepl("^sigz_bot",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^sigz_bot",TB_sum$variable)]*12)


mean(TB_sum$mean[grepl("^b1_r",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^b1_r",TB_sum$variable)]*12)

mean(TB_sum$mean[grepl("^b1_l",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^b1_l",TB_sum$variable)]*12)

mean(TB_sum$mean[grepl("^b2_r",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^b2_r",TB_sum$variable)]*12)

mean(TB_sum$mean[grepl("^b2_l",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^b2_l",TB_sum$variable)]*12)

mean(TB_sum$mean[grepl("^b3",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^b3",TB_sum$variable)]*12)

mean(TB_sum$mean[grepl("^b4",TB_sum$variable)])*12
sd(TB_sum$mean[grepl("^b4",TB_sum$variable)]*12)

## full

fit_full_sum <- fit_full$summary()



mean(fit_full_sum$mean[grepl("^sigx",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^sigx",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("^sigz_top",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^sigz_top",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("^sigz_bot",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^sigz_bot",fit_full_sum$variable)]*12)


mean(fit_full_sum$mean[grepl("^b1_r",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^b1_r",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("^b1_l",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^b1_l",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("^b2_r",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^b2_r",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("^b2_l",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^b2_l",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("^b3",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^b3",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("^b4",fit_full_sum$variable)])*12
sd(fit_full_sum$mean[grepl("^b4",fit_full_sum$variable)]*12)

mean(fit_full_sum$mean[grepl("rho",fit_full_sum$variable)])
