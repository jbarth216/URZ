functions {
  real bvn_prob(real h, real k, real rho) {
    real eps = 1e-8;
    real h_s = abs(h) < eps ? (h >= 0 ? eps : -eps) : h;
    real k_s = abs(k) < eps ? (k >= 0 ? eps : -eps) : k;
    real denom = sqrt(1 - rho^2);
    real a1 = (k - rho * h_s) / (h_s * denom);
    real a2 = (h - rho * k_s) / (k_s * denom);
    real delta = (h * k > 0 || (h * k == 0 && h + k >= 0)) ? 0 : 0.5;
    return 0.5 * (Phi(h) + Phi(k)) - owens_t(h_s, a1) - owens_t(k_s, a2) - delta;
  }

  real rect_prob_corr(real x_lo, real x_hi, real z_lo, real z_hi, real rho) {
    real p = bvn_prob(x_hi, z_hi, rho) - bvn_prob(x_lo, z_hi, rho)
           - bvn_prob(x_hi, z_lo, rho) + bvn_prob(x_lo, z_lo, rho);
    return fmax(1e-9, fmin(1 - 1e-9, p));
  }

  real partial_sum_lpmf(array[] int cs_slice,
                         int start, int end,
                         vector x, vector z, vector sz_top, vector sz_bot,
                         vector bh_v, array[] int ump, array[] int is_corner,
                         vector sigx, vector sigz, real rho,
                         vector b1_r, vector b1_l,
                         vector b2_r, vector b2_l,
                         vector b3, vector b4) {
    int n = end - start + 1;
    vector[n] x_s = x[start:end];
    vector[n] z_s = z[start:end];
    vector[n] sz_top_s = sz_top[start:end];
    vector[n] sz_bot_s = sz_bot[start:end];
    vector[n] bh_s = bh_v[start:end];
    array[n] int ump_s = ump[start:end];
    array[n] int corner_s = is_corner[start:end];

    real lp = 0;
    for (i in 1:n) {
      int j = ump_s[i];
      real sigx_i = sigx[j];
      real sigz_i = sigz[j];
      real b1 = bh_s[i] * b1_l[j] + (1 - bh_s[i]) * b1_r[j];
      real b2 = bh_s[i] * b2_l[j] + (1 - bh_s[i]) * b2_r[j];

      real hx_lo = (-0.83 + b2 - x_s[i]) / sigx_i;
      real hx_hi = ( 0.83 + b1 - x_s[i]) / sigx_i;
      real hz_lo = (sz_bot_s[i] + b4[j] - z_s[i]) / sigz_i;
      real hz_hi = (sz_top_s[i] + b3[j] - z_s[i]) / sigz_i;

      real prob;
      if (corner_s[i] == 1) {
        prob = rect_prob_corr(hx_lo, hx_hi, hz_lo, hz_hi, rho);   // full bivariate
      } else {
        real p_x = Phi(hx_hi) - Phi(hx_lo);
        real p_z = Phi(hz_hi) - Phi(hz_lo);
        prob = fmax(1e-9, fmin(1 - 1e-9, p_x * p_z));             // independent, cheap
      }

      if (cs_slice[i] == 1)
        lp += log(prob);
      else
        lp += log1m(prob);
    }
    return lp;
  }
}
data {
  int<lower=0> N;
  int<lower=0> U;
  array[N] int<lower=1, upper=U> ump;
  array[N] int<lower=0, upper=1> is_corner;
  vector[N] x;
  vector[N] z;
  vector[N] sz_top;
  vector[N] sz_bot;
  array[N] int<lower=0, upper=1> bh;
  array[N] int<lower=0, upper=1> cs;
  int<lower=1> grainsize;
}
transformed data {
  vector[N] bh_v = to_vector(bh);
}
parameters {
  real mu_log_sigx; real<lower=0> tau_log_sigx; vector[U] z_log_sigx;
  real mu_log_sigz; real<lower=0> tau_log_sigz; vector[U] z_log_sigz;

  real mu_b1_r; real<lower=0> tau_b1_r; vector[U] z_b1_r;
  real mu_b1_l; real<lower=0> tau_b1_l; vector[U] z_b1_l;
  real mu_b2_r; real<lower=0> tau_b2_r; vector[U] z_b2_r;
  real mu_b2_l; real<lower=0> tau_b2_l; vector[U] z_b2_l;
  real mu_b3;   real<lower=0> tau_b3;   vector[U] z_b3;
  real mu_b4;   real<lower=0> tau_b4;   vector[U] z_b4;

  real<lower=-1, upper=1> rho;
}
transformed parameters {
  vector<lower=0>[U] sigx = exp(mu_log_sigx + tau_log_sigx * z_log_sigx);
  vector<lower=0>[U] sigz = exp(mu_log_sigz + tau_log_sigz * z_log_sigz);

  vector[U] b1_r = mu_b1_r + tau_b1_r * z_b1_r;
  vector[U] b1_l = mu_b1_l + tau_b1_l * z_b1_l;
  vector[U] b2_r = mu_b2_r + tau_b2_r * z_b2_r;
  vector[U] b2_l = mu_b2_l + tau_b2_l * z_b2_l;
  vector[U] b3   = mu_b3   + tau_b3   * z_b3;
  vector[U] b4   = mu_b4   + tau_b4   * z_b4;
}
model {
  target += reduce_sum(partial_sum_lupmf, cs, grainsize,
                        x, z, sz_top, sz_bot, bh_v, ump, is_corner,
                        sigx, sigz, rho,
                        b1_r, b1_l, b2_r, b2_l, b3, b4);

  z_log_sigx ~ std_normal();
  z_log_sigz ~ std_normal();
  z_b1_r ~ std_normal(); z_b1_l ~ std_normal();
  z_b2_r ~ std_normal(); z_b2_l ~ std_normal();
  z_b3 ~ std_normal();   z_b4 ~ std_normal();

  mu_log_sigx ~ normal(log(0.2), 0.5); tau_log_sigx ~ normal(0, 0.5);
  mu_log_sigz ~ normal(log(0.2), 0.5); tau_log_sigz ~ normal(0, 0.5);

  mu_b1_r ~ normal(0, 0.2); tau_b1_r ~ normal(0, 0.1);
  mu_b1_l ~ normal(0, 0.2); tau_b1_l ~ normal(0, 0.1);
  mu_b2_r ~ normal(0, 0.2); tau_b2_r ~ normal(0, 0.1);
  mu_b2_l ~ normal(0, 0.2); tau_b2_l ~ normal(0, 0.1);
  mu_b3 ~ normal(0, 0.2);   tau_b3 ~ normal(0, 0.1);
  mu_b4 ~ normal(0, 0.2);   tau_b4 ~ normal(0, 0.1);

  rho ~ normal(0, 0.3);
}

