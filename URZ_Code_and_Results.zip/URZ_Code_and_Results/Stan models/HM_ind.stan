functions {
  real partial_sum_lpmf(array[] int cs_slice,
                         int start, int end,
                         vector x, vector z, vector sz_top, vector sz_bot,
                         vector bh_v, array[] int ump,
                         vector sigx, vector sigz,
                         vector b1_r, vector b1_l,
                         vector b2_r, vector b2_l,
                         vector b3, vector b4) {
    int n = end - start + 1;
    vector[n] x_s = x[start:end];
    vector[n] z_s = z[start:end];
    vector[n] sz_top_s = sz_top[start:end];
    vector[n] sz_bot_s = sz_bot[start:end];
    vector[n] bh_s = bh_v[start:end];
    array[n] int ump_s = ump[start:end];

    vector[n] sigx_i = sigx[ump_s];
    vector[n] sigz_i = sigz[ump_s];
    vector[n] b1 = bh_s .* b1_l[ump_s] + (1 - bh_s) .* b1_r[ump_s];
    vector[n] b2 = bh_s .* b2_l[ump_s] + (1 - bh_s) .* b2_r[ump_s];
    vector[n] b3_i = b3[ump_s];
    vector[n] b4_i = b4[ump_s];

    vector[n] p_x = Phi((0.83 + b1 - x_s) ./ sigx_i) - Phi((-0.83 + b2 - x_s) ./ sigx_i);
    vector[n] p_z = Phi((sz_top_s + b3_i - z_s) ./ sigz_i) - Phi((sz_bot_s + b4_i - z_s) ./ sigz_i);
    vector[n] prob = p_x .* p_z;
    vector[n] prob_clipped = fmax(rep_vector(1e-9, n), fmin(rep_vector(1 - 1e-9, n), prob));

    real lp = 0;
    for (i in 1:n) {
      if (cs_slice[i] == 1)
        lp += log(prob_clipped[i]);
      else
        lp += log1m(prob_clipped[i]);
    }
    return lp;
  }
}
data {
  int<lower=0> N;
  int<lower=0> U;
  array[N] int<lower=1, upper=U> ump;
  vector[N] x;
  vector[N] z;
  vector[N] sz_top;
  vector[N] sz_bot;
  array[N] int<lower=0, upper=1> bh;
  array[N] int<lower=0, upper=1> cs;
  int<lower=1> grainsize;
}
transformed data {
  vector[N] bh_v = to_vector(bh);
}
parameters {

  real mu_log_sigx;
  real<lower=0> tau_log_sigx;
  vector[U] z_log_sigx;

  real mu_log_sigz;
  real<lower=0> tau_log_sigz;
  vector[U] z_log_sigz;

  real mu_b1_r; real<lower=0> tau_b1_r; vector[U] z_b1_r;
  real mu_b1_l; real<lower=0> tau_b1_l; vector[U] z_b1_l;
  real mu_b2_r; real<lower=0> tau_b2_r; vector[U] z_b2_r;
  real mu_b2_l; real<lower=0> tau_b2_l; vector[U] z_b2_l;
  real mu_b3;   real<lower=0> tau_b3;   vector[U] z_b3;
  real mu_b4;   real<lower=0> tau_b4;   vector[U] z_b4;
}
transformed parameters {
  vector<lower=0>[U] sigx = exp(mu_log_sigx + tau_log_sigx * z_log_sigx);
  vector<lower=0>[U] sigz = exp(mu_log_sigz + tau_log_sigz * z_log_sigz);

  vector[U] b1_r = mu_b1_r + tau_b1_r * z_b1_r;
  vector[U] b1_l = mu_b1_l + tau_b1_l * z_b1_l;
  vector[U] b2_r = mu_b2_r + tau_b2_r * z_b2_r;
  vector[U] b2_l = mu_b2_l + tau_b2_l * z_b2_l;
  vector[U] b3   = mu_b3   + tau_b3   * z_b3;
  vector[U] b4   = mu_b4   + tau_b4   * z_b4;
}
model {
  target += reduce_sum(partial_sum_lupmf, cs, grainsize,
                        x, z, sz_top, sz_bot, bh_v, ump,
                        sigx, sigz, b1_r, b1_l, b2_r, b2_l, b3, b4);

  z_log_sigx ~ std_normal();
  z_log_sigz ~ std_normal();
  z_b1_r ~ std_normal(); z_b1_l ~ std_normal();
  z_b2_r ~ std_normal(); z_b2_l ~ std_normal();
  z_b3 ~ std_normal();   z_b4 ~ std_normal();

  mu_log_sigx ~ normal(log(0.2), 0.5);
  tau_log_sigx ~ normal(0, 0.5);
  mu_log_sigz ~ normal(log(0.2), 0.5);
  tau_log_sigz ~ normal(0, 0.5);

  mu_b1_r ~ normal(0, 0.2); tau_b1_r ~ normal(0, 0.1);
  mu_b1_l ~ normal(0, 0.2); tau_b1_l ~ normal(0, 0.1);
  mu_b2_r ~ normal(0, 0.2); tau_b2_r ~ normal(0, 0.1);
  mu_b2_l ~ normal(0, 0.2); tau_b2_l ~ normal(0, 0.1);
  mu_b3 ~ normal(0, 0.2);   tau_b3 ~ normal(0, 0.1);
  mu_b4 ~ normal(0, 0.2);   tau_b4 ~ normal(0, 0.1);
}
