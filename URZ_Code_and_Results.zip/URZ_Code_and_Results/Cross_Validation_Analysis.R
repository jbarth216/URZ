###Cross Validation Analysis

library(caret)
library(mgcv)
library(cmdstanr)

##Note: this assumes all stan models have been compiled 
##It also assumes that the initialization functions are live as well
##See the stan_code_clean.R file if you run into errors here

##Load data

df_called <- read.csv("df_called.csv")

set.seed(1234)
folds_umpstrat <- createFolds(y = as.factor(df_called$ump_id), k = 5)


###Independent model ####

inv_met_init_warmup <- readRDS("inv_met.rdata")


## Fold 1

train <- df_called[-c(folds_umpstrat$Fold1),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold1 <- model_ind$sample(data=stan_data, chains=4, parallel_chains = 4,
                              iter_warmup=100, iter_sampling=500, refresh=50,
                              init=init_fn, threads_per_chain = 3, step_size=.0977342,
                              inv_metric=inv_met_init_warmup)

model_summary_fold1 <- fit_fold1$summary()
write.csv(model_summary_fold1, "model_summary_fold1.csv", row.names = FALSE)

### Fold 2

train <- df_called[-c(folds_umpstrat$Fold2),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold2 <- model_ind$sample(data=stan_data, chains=4, parallel_chains = 4,
                              iter_warmup=100, iter_sampling=500, refresh=50,
                              init=init_fn, threads_per_chain = 3, step_size=.0977342,
                              inv_metric=inv_met_init_warmup)

model_summary_fold2 <- fit_fold2$summary()
write.csv(model_summary_fold2, "model_summary_fold2.csv", row.names = FALSE)

## Fold 3

train <- df_called[-c(folds_umpstrat$Fold3),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold3 <- model_ind$sample(data=stan_data, chains=4, parallel_chains = 4,
                              iter_warmup=100, iter_sampling=500, refresh=50,
                              init=init_fn, threads_per_chain = 3, step_size=.0977342,
                              inv_metric=inv_met_init_warmup)

model_summary_fold3 <- fit_fold3$summary()
write.csv(model_summary_fold3, "model_summary_fold3.csv", row.names = FALSE)

##fold 4

train <- df_called[-c(folds_umpstrat$Fold4),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold4 <- model_ind$sample(data=stan_data, chains=4, parallel_chains = 4,
                              iter_warmup=100, iter_sampling=500, refresh=50,
                              init=init_fn, threads_per_chain = 3, step_size=.0977342,
                              inv_metric=inv_met_init_warmup)

model_summary_fold4 <- fit_fold4$summary()
write.csv(model_summary_fold4, "model_summary_fold4.csv", row.names = FALSE)

##Fold 5

train <- df_called[-c(folds_umpstrat$Fold5),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold5 <- model_ind$sample(data=stan_data, chains=4, parallel_chains = 4,
                              iter_warmup=100, iter_sampling=500, refresh=50,
                              init=init_fn, threads_per_chain = 3, step_size=.0977342,
                              inv_metric=inv_met_init_warmup)

model_summary_fold5 <- fit_fold5$summary()
write.csv(model_summary_fold5, "model_summary_fold5.csv", row.names = FALSE)

params_list <- list()

for (i in 1:94){
  params_list[[i]] <- c(paste0("sigx[",i,"]"),
                        paste0("sigz[",i,"]"),
                        paste0("b1_r[",i,"]"),
                        paste0("b1_l[",i,"]"),
                        paste0("b2_r[",i,"]"),
                        paste0("b2_l[",i,"]"),
                        paste0("b3[",i,"]"),
                        paste0("b4[",i,"]"))
}

#model_summary_fold1 <- read.csv("model_summary_fold1.csv")
#model_summary_fold2 <- read.csv("model_summary_fold2.csv")
#model_summary_fold3 <- read.csv("model_summary_fold3.csv")
#model_summary_fold4 <- read.csv("model_summary_fold4.csv")
#model_summary_fold5 <- read.csv("model_summary_fold5.csv")

CV_results_hm_folds <- list(ump_name = Res23$ump_name[Res23$num_calls>=1000],
                            ump_id = Res23$ump_id[Res23$num_calls>=1000],
                            MSE_hm_folds=matrix(0,90,5))


## Save probabilities
hm_val_probs <- list()

for (j in 1:90){
  u <- CV_results_hm_folds$ump_id[j]
  par <- params_list[[u]]
  
  test <- df_called[folds_umpstrat$Fold1,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold1$mean[model_summary_fold1$variable %in% par]
  lp1<-pitch_logprob_BIAS_STANCE2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                  pars[7], pars[8], test)
  
  test <- df_called[folds_umpstrat$Fold2,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold2$mean[model_summary_fold2$variable %in% par]
  lp2<-pitch_logprob_BIAS_STANCE2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                  pars[7], pars[8], test)
  
  test <- df_called[folds_umpstrat$Fold3,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold3$mean[model_summary_fold3$variable %in% par]
  lp3 <-pitch_logprob_BIAS_STANCE2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                   pars[7], pars[8], test)
  
  test <- df_called[folds_umpstrat$Fold4,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold4$mean[model_summary_fold4$variable %in% par]
  lp4 <-pitch_logprob_BIAS_STANCE2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                   pars[7], pars[8], test)
  
  test <- df_called[folds_umpstrat$Fold5,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold5$mean[model_summary_fold5$variable %in% par]
  lp5 <-pitch_logprob_BIAS_STANCE2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                   pars[7], pars[8], test)
  
  lp_sm <- numeric(5)
  lp_sm[1] <- mean((1-exp(lp1))^2)
  lp_sm[2] <- mean((1-exp(lp2))^2)
  lp_sm[3] <- mean((1-exp(lp3))^2)
  lp_sm[4] <- mean((1-exp(lp4))^2)
  lp_sm[5] <- mean((1-exp(lp5))^2)
  
  CV_results_hm_folds$MSE_hm_folds[j,] <- lp_sm
  
  hm_val_probs[[j]] <- c(lp1,lp2,lp3,lp4,lp5)
  
  ### Save probabilities
}

###Table calcs
###Overall LL
sum(unlist(hm_val_probs))/90


### TB Model ####

inv_met_init_warmup <- readRDS("inv_met_init_TB.rdata")

##fold 1

train <- df_called[-c(folds_umpstrat$Fold1),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold1_TB <- model_TB$sample(data=stan_data, chains=4, parallel_chains = 4,
                                iter_warmup=100, iter_sampling=500, refresh=50,
                                init=init_fn_TB, threads_per_chain = 3, step_size=.1209,
                                inv_metric=inv_met_init_warmup)

saveRDS(fit_fold1_TB, "fit_fold1_TB.rdata")

model_summary_fold1_TB <- fit_fold1_TB$summary()
write.csv(model_summary_fold1_TB, "model_summary_fold1_TB.csv", row.names = FALSE)

### Fold 2

train <- df_called[-c(folds_umpstrat$Fold2),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold2_TB <- model_TB$sample(data=stan_data, chains=4, parallel_chains = 4,
                                iter_warmup=100, iter_sampling=500, refresh=50,
                                init=init_fn_TB, threads_per_chain = 3, step_size=.1209,
                                inv_metric=inv_met_init_warmup)

saveRDS(fit_fold2_TB, "fit_fold2_TB.rdata")

model_summary_fold2_TB <- fit_fold2_TB$summary()
write.csv(model_summary_fold2_TB, "model_summary_fold2_TB.csv", row.names = FALSE)

## Fold 3

train <- df_called[-c(folds_umpstrat$Fold3),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold3_TB <- model_TB$sample(data=stan_data, chains=4, parallel_chains = 4,
                                iter_warmup=100, iter_sampling=500, refresh=50,
                                init=init_fn_TB, threads_per_chain = 3, step_size=.1209,
                                inv_metric=inv_met_init_warmup)

saveRDS(fit_fold3_TB, "fit_fold3_TB.rdata")

model_summary_fold3_TB <- fit_fold3_TB$summary()
write.csv(model_summary_fold3_TB, "model_summary_fold3_TB.csv", row.names = FALSE)

##fold 4

train <- df_called[-c(folds_umpstrat$Fold4),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold4_TB <- model_TB$sample(data=stan_data, chains=4, parallel_chains = 4,
                                iter_warmup=100, iter_sampling=500, refresh=50,
                                init=init_fn_TB, threads_per_chain = 3, step_size=.1209,
                                inv_metric=inv_met_init_warmup)

saveRDS(fit_fold4_TB, "fit_fold4_TB.rdata")

model_summary_fold4_TB <- fit_fold4_TB$summary()
write.csv(model_summary_fold4_TB, "model_summary_fold4_TB.csv", row.names = FALSE)

##Fold 5

train <- df_called[-c(folds_umpstrat$Fold5),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold5_TB <- model_TB$sample(data=stan_data, chains=4, parallel_chains = 4,
                                iter_warmup=100, iter_sampling=500, refresh=50,
                                init=init_fn_TB, threads_per_chain = 3, step_size=.1209,
                                inv_metric=inv_met_init_warmup)

saveRDS(fit_fold5_TB, "fit_fold5_TB.rdata")

model_summary_fold5_TB <- fit_fold5_TB$summary()
write.csv(model_summary_fold5_TB, "model_summary_fold5_TB.csv", row.names = FALSE)


params_list <- list()

for (i in 1:94){
  params_list[[i]] <- c(paste0("sigx[",i,"]"),
                        paste0("sigz_top[",i,"]"),
                        paste0("sigz_bot[",i,"]"),
                        paste0("b1_r[",i,"]"),
                        paste0("b1_l[",i,"]"),
                        paste0("b2_r[",i,"]"),
                        paste0("b2_l[",i,"]"),
                        paste0("b3[",i,"]"),
                        paste0("b4[",i,"]"))
}

#model_summary_fold1$mean[model_summary_fold1$variable %in% params_list[[1]]]

setwd("C:\\Users\\Jackson_Barth\\Box\\Research\\Baseball\\DATA")

#model_summary_fold1_TB <- read.csv("model_summary_fold1_TB.csv")
#model_summary_fold2_TB <- read.csv("model_summary_fold2_TB.csv")
#model_summary_fold3_TB <- read.csv("model_summary_fold3_TB.csv")
#model_summary_fold4_TB <- read.csv("model_summary_fold4_TB.csv")
#model_summary_fold5_TB <- read.csv("model_summary_fold5_TB.csv")


CV_results_hm_TB_folds <- list(ump_name = Res23$ump_name[Res23$num_calls>=1000],
                               ump_id = Res23$ump_id[Res23$num_calls>=1000],
                               MSE_hm_TB_folds=matrix(0,90,5))

hm_TB_val_probs <- list()


for (j in 1:90){
  u <- CV_results_hm_TB_folds$ump_id[j]
  par <- params_list[[u]]
  
  test <- df_called[folds_umpstrat$Fold1,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold1_TB$mean[model_summary_fold1_TB$variable %in% par]
  lp1<-pitch_logprob_BIAS_STANCE_TB2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                     pars[7], pars[8], pars[9], test)
  
  test <- df_called[folds_umpstrat$Fold2,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold2_TB$mean[model_summary_fold2_TB$variable %in% par]
  lp2<-pitch_logprob_BIAS_STANCE_TB2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                     pars[7], pars[8], pars[9], test)
  
  test <- df_called[folds_umpstrat$Fold3,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold3_TB$mean[model_summary_fold3_TB$variable %in% par]
  lp3 <-pitch_logprob_BIAS_STANCE_TB2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                      pars[7], pars[8], pars[9], test)
  
  test <- df_called[folds_umpstrat$Fold4,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold4_TB$mean[model_summary_fold4_TB$variable %in% par]
  lp4 <-pitch_logprob_BIAS_STANCE_TB2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                      pars[7], pars[8], pars[9], test)
  
  test <- df_called[folds_umpstrat$Fold5,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold5_TB$mean[model_summary_fold5_TB$variable %in% par]
  lp5 <-pitch_logprob_BIAS_STANCE_TB2(pars[1], pars[2], pars[3], pars[4], pars[5], pars[6],
                                      pars[7], pars[8], pars[9], test)
  
  lp_sm <- numeric(5)
  lp_sm[1] <- mean((1-exp(lp1))^2)
  lp_sm[2] <- mean((1-exp(lp2))^2)
  lp_sm[3] <- mean((1-exp(lp3))^2)
  lp_sm[4] <- mean((1-exp(lp4))^2)
  lp_sm[5] <- mean((1-exp(lp5))^2)
  
  CV_results_hm_TB_folds$MSE_hm_TB_folds[j,] <- lp_sm
  
  hm_TB_val_probs[[j]] <- c(lp1,lp2,lp3,lp4,lp5)
  
}

###Log loss
sum(unlist(hm_TB_val_probs))/90

### rho1

corn_met <- readRDS("corn_met.rdata")

###Fold 1

train <- df_called[-c(folds_umpstrat$Fold1),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold1_rho1 <- model_rho1_corner$sample(data=stan_data, chains=4, parallel_chains = 4,
                                           iter_warmup=100, iter_sampling=500, refresh=50,
                                           init=init_fn_rho1, threads_per_chain = 3, step_size=.08828,
                                           inv_metric=corn_met)

saveRDS(fit_fold1_rho1, "fit_fold1_rho1.rdata")

model_summary_fold1_rho1 <- fit_fold1_rho1$summary()
write.csv(model_summary_fold1_rho1, "model_summary_fold1_rho1.csv", row.names = FALSE)

### Fold 2

train <- df_called[-c(folds_umpstrat$Fold2),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold2_rho1 <- model_rho1_corner$sample(data=stan_data, chains=4, parallel_chains = 4,
                                           iter_warmup=100, iter_sampling=500, refresh=50,
                                           init=init_fn_rho1, threads_per_chain = 3, step_size=.08828,
                                           inv_metric=corn_met)

saveRDS(fit_fold2_rho1, "fit_fold2_rho1.rdata")

model_summary_fold2_rho1 <- fit_fold2_rho1$summary()
write.csv(model_summary_fold2_rho1, "model_summary_fold2_rho1.csv", row.names = FALSE)

## Fold 3

train <- df_called[-c(folds_umpstrat$Fold3),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold3_rho1 <- model_rho1_corner$sample(data=stan_data, chains=4, parallel_chains = 4,
                                           iter_warmup=100, iter_sampling=500, refresh=50,
                                           init=init_fn_rho1, threads_per_chain = 3, step_size=.08828,
                                           inv_metric=corn_met)

saveRDS(fit_fold3_rho1, "fit_fold3_rho1.rdata")

model_summary_fold3_rho1 <- fit_fold3_rho1$summary()
write.csv(model_summary_fold3_rho1, "model_summary_fold3_rho1.csv", row.names = FALSE)

##fold 4

train <- df_called[-c(folds_umpstrat$Fold4),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold4_rho1 <- model_rho1_corner$sample(data=stan_data, chains=4, parallel_chains = 4,
                                           iter_warmup=100, iter_sampling=500, refresh=50,
                                           init=init_fn_rho1, threads_per_chain = 3, step_size=.08828,
                                           inv_metric=corn_met)

saveRDS(fit_fold4_rho1, "fit_fold4_rho1.rdata")

model_summary_fold4_rho1 <- fit_fold4_rho1$summary()
write.csv(model_summary_fold4_rho1, "model_summary_fold4_rho1.csv", row.names = FALSE)

##Fold 5

train <- df_called[-c(folds_umpstrat$Fold5),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold5_rho1 <- model_rho1_corner$sample(data=stan_data, chains=4, parallel_chains = 4,
                                           iter_warmup=100, iter_sampling=500, refresh=50,
                                           init=init_fn_rho1, threads_per_chain = 3, step_size=.08828,
                                           inv_metric=corn_met)

saveRDS(fit_fold5_rho1, "fit_fold5_rho1.rdata")

model_summary_fold5_rho1 <- fit_fold5_rho1$summary()
write.csv(model_summary_fold5_rho1, "model_summary_fold5_rho1.csv", row.names = FALSE)


for (i in 1:94){
  params_list[[i]] <- c(paste0("sigx[",i,"]"),
                        paste0("sigz[",i,"]"),
                        paste0("b1_r[",i,"]"),
                        paste0("b1_l[",i,"]"),
                        paste0("b2_r[",i,"]"),
                        paste0("b2_l[",i,"]"),
                        paste0("b3[",i,"]"),
                        paste0("b4[",i,"]"),
                        "rho")
}

#model_summary_fold1_rho1 <- read.csv("model_summary_fold1_rho1.csv")
#model_summary_fold2_rho1 <- read.csv("model_summary_fold2_rho1.csv")
#model_summary_fold3_rho1 <- read.csv("model_summary_fold3_rho1.csv")
#model_summary_fold4_rho1 <- read.csv("model_summary_fold4_rho1.csv")
#model_summary_fold5_rho1 <- read.csv("model_summary_fold5_rho1.csv")


CV_results_hm_rho1_folds <- list(ump_name = Res23$ump_name[Res23$num_calls>=1000],
                                 ump_id = Res23$ump_id[Res23$num_calls>=1000],
                                 MSE_hm_rho1_folds=matrix(0,90,5))

hm_rho1_val_probs <- list()


for (j in 1:90){
  u <- CV_results_hm_rho1_folds$ump_id[j]
  par <- params_list[[u]]
  
  test <- df_called[folds_umpstrat$Fold1,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold1_rho1$mean[model_summary_fold1_rho1$variable %in% par]
  lp1<-pitch_logprob_BIAS_STANCE_rho2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                      pars[7], pars[8], pars[9], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold2,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold2_rho1$mean[model_summary_fold2_rho1$variable %in% par]
  lp2<-pitch_logprob_BIAS_STANCE_rho2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                      pars[7], pars[8], pars[9], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold3,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold3_rho1$mean[model_summary_fold3_rho1$variable %in% par]
  lp3 <-pitch_logprob_BIAS_STANCE_rho2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                       pars[7], pars[8], pars[9], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold4,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold4_rho1$mean[model_summary_fold4_rho1$variable %in% par]
  lp4 <-pitch_logprob_BIAS_STANCE_rho2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                       pars[7], pars[8], pars[9], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold5,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold5_rho1$mean[model_summary_fold5_rho1$variable %in% par]
  lp5 <-pitch_logprob_BIAS_STANCE_rho2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                       pars[7], pars[8], pars[9], pars[1], test)
  
  lp_sm <- numeric(5)
  lp_sm[1] <- mean((1-exp(lp1))^2)
  lp_sm[2] <- mean((1-exp(lp2))^2)
  lp_sm[3] <- mean((1-exp(lp3))^2)
  lp_sm[4] <- mean((1-exp(lp4))^2)
  lp_sm[5] <- mean((1-exp(lp5))^2)
  
  CV_results_hm_rho1_folds$MSE_hm_rho1_folds[j,] <- lp_sm
  
  hm_rho1_val_probs[[j]] <- c(lp1,lp2,lp3,lp4,lp5)
  
}

### Log Loss
sum(unlist(hm_rho1_val_probs))/90

### BOTH

inv_met_bth <- readRDS(inv_met_bth.rdata)

train <- df_called[-c(folds_umpstrat$Fold1),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold1_bth <- model_bth$sample(data=stan_data, chains=4, parallel_chains = 4,
                                  iter_warmup=100, iter_sampling=500, refresh=50,
                                  init=init_fn_bth, threads_per_chain = 3, step_size=0.0794531,
                                  inv_metric=inv_met_bth)

saveRDS(fit_fold1_bth, "fit_fold1_bth.rdata")

model_summary_fold1_bth <- fit_fold1_bth$summary()
write.csv(model_summary_fold1_bth, "model_summary_fold1_bth.csv", row.names = FALSE)

### Fold 2

train <- df_called[-c(folds_umpstrat$Fold2),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold2_bth <- model_bth$sample(data=stan_data, chains=4, parallel_chains = 4,
                                  iter_warmup=100, iter_sampling=500, refresh=50,
                                  init=init_fn_bth, threads_per_chain = 3, step_size=0.0794531,
                                  inv_metric=inv_met_bth)

saveRDS(fit_fold2_bth, "fit_fold2_bth.rdata")

model_summary_fold2_bth <- fit_fold2_bth$summary()
write.csv(model_summary_fold2_bth, "model_summary_fold2_bth.csv", row.names = FALSE)

## Fold 3

train <- df_called[-c(folds_umpstrat$Fold3),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold3_bth <- model_bth$sample(data=stan_data, chains=4, parallel_chains = 4,
                                  iter_warmup=100, iter_sampling=500, refresh=50,
                                  init=init_fn_bth, threads_per_chain = 3, step_size=0.0794531,
                                  inv_metric=inv_met_bth)

saveRDS(fit_fold3_bth, "fit_fold3_bth.rdata")

model_summary_fold3_bth <- fit_fold3_bth$summary()
write.csv(model_summary_fold3_bth, "model_summary_fold3_bth.csv", row.names = FALSE)

##fold 4

train <- df_called[-c(folds_umpstrat$Fold4),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold4_bth <- model_bth$sample(data=stan_data, chains=4, parallel_chains = 4,
                                  iter_warmup=100, iter_sampling=500, refresh=50,
                                  init=init_fn_bth, threads_per_chain = 3, step_size=0.0794531,
                                  inv_metric=inv_met_bth)

saveRDS(fit_fold4_bth, "fit_fold4_bth.rdata")

model_summary_fold4_bth <- fit_fold4_bth$summary()
write.csv(model_summary_fold4_bth, "model_summary_fold4_bth.csv", row.names = FALSE)

##Fold 5

train <- df_called[-c(folds_umpstrat$Fold5),]

stan_data <- list(
  N = nrow(train),
  U = 94,
  ump = train$ump_id,
  is_corner = train$rho_diff,
  x = train$plate_x,
  z = train$plate_z,
  sz_top = train$sz_top,
  sz_bot = train$sz_bot,
  bh = as.integer(train$stand == "L"),
  cs = train$predicted,
  grainsize=50000
)

fit_fold5_bth <- model_bth$sample(data=stan_data, chains=4, parallel_chains = 4,
                                  iter_warmup=100, iter_sampling=500, refresh=50,
                                  init=init_fn_bth, threads_per_chain = 3, step_size=0.0794531,
                                  inv_metric=inv_met_bth)

saveRDS(fit_fold5_bth, "fit_fold5_bth.rdata")

model_summary_fold5_bth <- fit_fold5_bth$summary()
write.csv(model_summary_fold5_bth, "model_summary_fold5_bth.csv", row.names = FALSE)

#### Results

for (i in 1:94){
  params_list[[i]] <- c(paste0("sigx[",i,"]"),
                        paste0("sigz_top[",i,"]"),
                        paste0("sigz_bot[",i,"]"),
                        paste0("b1_r[",i,"]"),
                        paste0("b1_l[",i,"]"),
                        paste0("b2_r[",i,"]"),
                        paste0("b2_l[",i,"]"),
                        paste0("b3[",i,"]"),
                        paste0("b4[",i,"]"),
                        "rho")
}


#model_summary_fold1_bth <- read.csv("model_summary_fold1_bth.csv")
#model_summary_fold2_bth <- read.csv("model_summary_fold2_bth.csv")
#model_summary_fold3_bth <- read.csv("model_summary_fold3_bth.csv")
#model_summary_fold4_bth <- read.csv("model_summary_fold4_bth.csv")
#model_summary_fold5_bth <- read.csv("model_summary_fold5_bth.csv")


CV_results_hm_bth_folds <- list(ump_name = Res23$ump_name[Res23$num_calls>=1000],
                                ump_id = Res23$ump_id[Res23$num_calls>=1000],
                                MSE_hm_bth_folds=matrix(0,90,5))

hm_bth_val_probs <- list()


for (j in 1:90){
  u <- CV_results_hm_bth_folds$ump_id[j]
  par <- params_list[[u]]
  
  test <- df_called[folds_umpstrat$Fold1,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold1_bth$mean[model_summary_fold1_bth$variable %in% par]
  lp1<-pitch_logprob_BIAS_STANCE_bth2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                      pars[7], pars[8], pars[9], pars[10], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold2,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold2_bth$mean[model_summary_fold2_bth$variable %in% par]
  lp2<-pitch_logprob_BIAS_STANCE_bth2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                      pars[7], pars[8], pars[9], pars[10], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold3,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold3_bth$mean[model_summary_fold3_bth$variable %in% par]
  lp3 <-pitch_logprob_BIAS_STANCE_bth2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                       pars[7], pars[8], pars[9], pars[10], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold4,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold4_bth$mean[model_summary_fold4_bth$variable %in% par]
  lp4 <-pitch_logprob_BIAS_STANCE_bth2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                       pars[7], pars[8], pars[9], pars[10], pars[1], test)
  
  test <- df_called[folds_umpstrat$Fold5,]
  test <- test[test$ump_id == u,]
  pars <- model_summary_fold5_bth$mean[model_summary_fold5_bth$variable %in% par]
  lp5 <-pitch_logprob_BIAS_STANCE_bth2(pars[2], pars[3], pars[4], pars[5], pars[6],
                                       pars[7], pars[8], pars[9], pars[10], pars[1], test)
  
  lp_sm <- numeric(5)
  lp_sm[1] <- mean((1-exp(lp1))^2)
  lp_sm[2] <- mean((1-exp(lp2))^2)
  lp_sm[3] <- mean((1-exp(lp3))^2)
  lp_sm[4] <- mean((1-exp(lp4))^2)
  lp_sm[5] <- mean((1-exp(lp5))^2)
  
  CV_results_hm_bth_folds$MSE_hm_bth_folds[j,] <- lp_sm
  
  hm_bth_val_probs[[j]] <- c(lp1,lp2,lp3,lp4,lp5)
  
}

###log loss

sum(unlist(hm_bth_val_probs))/90

### GAM (batter handedness only)
### Note: I am excluding the version of the gam by both pitcher and batter handedness
### as it did not perform well at all. This version has superior accuracy and
### is a better comparision overall. This may not hold for a larger dataset.


### Individual - BH only ####

### add folds to df_called
df_called$fold <- 0
df_called$fold[folds_umpstrat[[1]]] <- 1
df_called$fold[folds_umpstrat[[2]]] <- 2
df_called$fold[folds_umpstrat[[3]]] <- 3
df_called$fold[folds_umpstrat[[4]]] <- 4
df_called$fold[folds_umpstrat[[5]]] <- 5

CV_results_hg2_folds <- list(ump_name = Res23$ump_name[Res23$num_calls>=1000],
                             ump_id = Res23$ump_id[Res23$num_calls>=1000],
                             MSE_hg2_folds=matrix(0,90,5),
                             MSE_hg2_df=matrix(0,90,5))

hg2_val_probs <- list()


for (j in c(1:90)){
  
  start <- Sys.time()
  u <- CV_results_hg2_folds$ump_id[j]
  df <- df_called[df_called$ump_id==u,]
  df$zs <- 2*((df$plate_z-df$sz_bot)/(df$sz_top-df$sz_bot)) + 1.5
  
  N <- nrow(df)
  #MSE <- numeric(5)
  #MSE_baseline <- numeric(5)
  MSE_hg2 <- numeric(5)
  MSE_hg2_df <- numeric(5)
  hg2_val_probs_ump <- list()
  
  for(i in 1:5){
    train1 <-df[df$fold!=i,] ##For fold 1
    val1 <- df[df$fold==i,]
    
    pitches <- data.frame(x = train1$plate_x, z=train1$zs,
                          called_strike=train1$predicted,
                          batter_hand=train1$stand,
                          pitcher_hand=train1$p_throws)
    
    pitches_val1 <- data.frame(x = val1$plate_x, z=val1$zs,
                               called_strike=val1$predicted,
                               batter_hand=val1$stand,
                               pitcher_hand=val1$p_throws,
                               index = 1:nrow(val1))
    
    subset_RHB <- subset(pitches, batter_hand == "R")
    subset_LHB <- subset(pitches, batter_hand == "L")
    
    # Fit GAM models for each group
    gam_RHB <- gam(called_strike ~ s(x, z), family = binomial, data = subset_RHB, method = "REML")
    gam_LHB <- gam(called_strike ~ s(x, z), family = binomial, data = subset_LHB, method = "REML")
    
    subset_RHB_val <- subset(pitches_val1, batter_hand == "R")
    subset_LHB_val <- subset(pitches_val1, batter_hand == "L")
    
    subset_RHB_val$prob <- predict(gam_RHB, newdata = subset_RHB_val[,1:2],type="response")
    subset_LHB_val$prob <- predict(gam_LHB, newdata = subset_LHB_val[,1:2],type="response")
    
    pval1 <- rbind(subset_RHB_val, subset_LHB_val)
    pval1 <- pval1[order(pval1$index),]
    MSE_hg2[i] <- mean((pval1$called_strike - pval1$prob)^2)
    MSE_hg2_df[i] <- sum(gam_RHB$edf) + sum(gam_LHB$edf)
    hg2_val_probs_ump[[i]] <- log(ifelse(pval1$called_strike==1,
                                         pval1$prob, 1-pval1$prob) )
    
    if(gam_RHB$outer.info$conv!="full convergence"){print(paste("RHB",i,j, nrow(subset_RHB_LHP)))}
    if(gam_LHB$outer.info$conv!="full convergence"){print(paste("LHB",i,j, nrow(subset_LHB_LHP)))}
    
    #print(i)
    
  }
  
  CV_results_hg2_folds$MSE_hg2_folds[j,] <- MSE_hg2
  CV_results_hg2_folds$MSE_hg2_df[j,] <- MSE_hg2_df
  
  hg2_val_probs[[j]] <- unlist(hg2_val_probs_ump)
  
  
  print(j)
  print(Sys.time() - start)
}

## LL
sum(unlist(hg2_val_probs))/90

### Analyze results for Table ####

### do BSS for all

f <- CV_results_hm_folds$MSE_hm_folds
f_TB <- CV_results_hm_TB_folds$MSE_hm_TB_folds
f_rho1 <- CV_results_hm_rho1_folds$MSE_hm_rho1_folds
f_bth <- CV_results_hm_bth_folds$MSE_hm_bth_folds
f_hg <- CV_results_hg2_folds$MSE_hg2_folds
f_naive <- numeric(90)

quantile(1 - apply(f,1,mean)/f_naive,c(.05,.5,.95))
quantile(1 - apply(f_TB,1,mean)/f_naive,c(.05,.5,.95))
quantile(1 - apply(f_rho1,1,mean)/f_naive,c(.05,.5,.95))
quantile(1 - apply(f_bth,1,mean)/f_naive,c(.05,.5,.95))
quantile(1 - apply(f_hg,1,mean)/f_naive,c(.05,.5,.95))

for(i in 1:90){
  u <- CV_results_hm_bth_folds$ump_id[i]
  df_u <- df_called[df_called$ump_id==u,]
  f_naive[i] <- sum(df_u$correct==0)/nrow(df_u)
}

TS_diffs <- function(diffs,co=1.96){
  TS <- sqrt(5)*apply(diffs,1,mean)/apply(diffs,1,sd)
  c(length(TS[TS> co]), length(TS[TS< -1*co]))
}

TS_diffs(f - f_TB)
TS_diffs(f-f_rho1)
TS_diffs(f-f_bth)
TS_diffs(f-f_hg)

TS_diffs(f - f_TB,1)
TS_diffs(f-f_rho1,1)
TS_diffs(f-f_bth,1)
TS_diffs(f-f_hg,1)

TS_diffs(f - f_TB,0)
TS_diffs(f-f_rho1,0)
TS_diffs(f-f_bth,0)
TS_diffs(f-f_hg,0)

### This is the rejection region at bonferonni adjusted alpha for 90 tests
TS_diffs(f - f_TB, 3.45)
TS_diffs(f-f_rho1, 3.45)
TS_diffs(f-f_bth, 3.45)
TS_diffs(f-f_hg, 3.45)

###Compared to gam
TS_diffs(f_hg-f)
TS_diffs(f_hg - f_TB)
TS_diffs(f_hg-f_rho1)
TS_diffs(f_hg-f_bth)




